#include "pch.h"
#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace MatrixAssignment4
{
	TEST_CLASS(MatrixAssignment4)
	{
	public:
		
		TEST_METHOD(TestMethod1)
		{
		}
	};
}
